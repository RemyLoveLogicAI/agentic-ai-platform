# Repository Applications

This directory contains sample applications for testing the packaging and analysis tools.

- `app1/`: A simple application.
- `app2/`: Another simple application, with some differences from `app1`.
