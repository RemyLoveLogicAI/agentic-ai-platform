# Utility functions for App 2
def helper_function():
    return "This is a helper."
