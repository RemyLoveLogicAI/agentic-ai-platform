# Application 1 Main File
def main():
    print("Hello from App 1")

if __name__ == "__main__":
    main()
